const express = require('express');

const app = express();

app.get('/', function(req ,res){
    res.send('Hey,you are awesome!')

})

app.listen(9000,function(req,res){
    console.log('Running...')
});
